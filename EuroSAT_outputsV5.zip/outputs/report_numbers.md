# EuroSAT report numbers

Run mode: full; single training seed: 42.
Test-set bootstrap intervals describe variation from resampling the test set only, not variation across training seeds.

## Master results

| pipeline                     |   accuracy | accuracy 95% test-set bootstrap CI   |   macro-F1 | macro-F1 95% test-set bootstrap CI   |   macro precision |   macro recall |   parameters |   checkpoint MB |   batch-1 latency ms | GPU      |
|:-----------------------------|-----------:|:-------------------------------------|-----------:|:-------------------------------------|------------------:|---------------:|-------------:|----------------:|---------------------:|:---------|
| Fine-tuned ViT (single seed) |   0.991852 | [0.9889, 0.9946]                     |   0.991568 | [0.9886, 0.9943]                     |          0.991733 |       0.991422 |     85806346 |        327.372  |              6.93816 | Tesla T4 |
| Fine-tuned CNN (single seed) |   0.988148 | [0.9844, 0.9911]                     |   0.987633 | [0.9840, 0.9908]                     |          0.987338 |       0.988022 |     23520842 |         89.7744 |             13.2728  | Tesla T4 |

## Dataset split counts

| split      |   images |   AnnualCrop |   Forest |   HerbaceousVegetation |   Highway |   Industrial |   Pasture |   PermanentCrop |   Residential |   River |   SeaLake |
|:-----------|---------:|-------------:|---------:|-----------------------:|----------:|-------------:|----------:|----------------:|--------------:|--------:|----------:|
| train      |    18900 |         2100 |     2100 |                   2100 |      1750 |         1750 |      1400 |            1750 |          2100 |    1750 |      2100 |
| validation |     4050 |          450 |      450 |                    450 |       375 |          375 |       300 |             375 |           450 |     375 |       450 |
| test       |     4050 |          450 |      450 |                    450 |       375 |          375 |       300 |             375 |           450 |     375 |       450 |

## Model details

| pipeline                                  |   total parameters | EuroSAT-trained   | pretraining                   |   input size used |
|:------------------------------------------|-------------------:|:------------------|:------------------------------|------------------:|
| vit_base_patch16_224.augreg_in21k_ft_in1k |           85806346 | Yes               | ImageNet-21k then ImageNet-1k |               224 |
| resnetv2_50x1_bit.goog_in21k_ft_in1k      |           23520842 | Yes               | ImageNet-21k then ImageNet-1k |               224 |


Paired accuracy difference ViT minus CNN 95% interval: [0.0002, 0.0072].
McNemar H1: supported for ViT; b=31, c=16, p=0.0399861.
H2: not supported; H3: supported.

## Per-class metrics

| pipeline       | class                |   precision |   recall |       F1 |
|:---------------|:---------------------|------------:|---------:|---------:|
| Fine-tuned ViT | AnnualCrop           |    0.984479 | 0.986667 | 0.985572 |
| Fine-tuned ViT | Forest               |    1        | 0.995556 | 0.997773 |
| Fine-tuned ViT | HerbaceousVegetation |    0.978118 | 0.993333 | 0.985667 |
| Fine-tuned ViT | Highway              |    0.997326 | 0.994667 | 0.995995 |
| Fine-tuned ViT | Industrial           |    0.997326 | 0.994667 | 0.995995 |
| Fine-tuned ViT | Pasture              |    0.983278 | 0.98     | 0.981636 |
| Fine-tuned ViT | PermanentCrop        |    0.986559 | 0.978667 | 0.982597 |
| Fine-tuned ViT | Residential          |    0.995565 | 0.997778 | 0.99667  |
| Fine-tuned ViT | River                |    0.994681 | 0.997333 | 0.996005 |
| Fine-tuned ViT | SeaLake              |    1        | 0.995556 | 0.997773 |
| Fine-tuned CNN | AnnualCrop           |    0.982262 | 0.984444 | 0.983352 |
| Fine-tuned CNN | Forest               |    0.997773 | 0.995556 | 0.996663 |
| Fine-tuned CNN | HerbaceousVegetation |    0.986517 | 0.975556 | 0.981006 |
| Fine-tuned CNN | Highway              |    0.986772 | 0.994667 | 0.990704 |
| Fine-tuned CNN | Industrial           |    0.986667 | 0.986667 | 0.986667 |
| Fine-tuned CNN | Pasture              |    0.958065 | 0.99     | 0.97377  |
| Fine-tuned CNN | PermanentCrop        |    0.989071 | 0.965333 | 0.977058 |
| Fine-tuned CNN | Residential          |    0.995546 | 0.993333 | 0.994438 |
| Fine-tuned CNN | River                |    0.997326 | 0.994667 | 0.995995 |
| Fine-tuned CNN | SeaLake              |    0.993377 | 1        | 0.996678 |

## Confusion pairs

| pipeline       | unordered pair                       |   errors |   share of all errors |
|:---------------|:-------------------------------------|---------:|----------------------:|
| Fine-tuned ViT | AnnualCrop ↔ PermanentCrop           |        7 |             0.212121  |
| Fine-tuned ViT | AnnualCrop ↔ Pasture                 |        5 |             0.151515  |
| Fine-tuned ViT | HerbaceousVegetation ↔ Pasture       |        5 |             0.151515  |
| Fine-tuned ViT | HerbaceousVegetation ↔ PermanentCrop |        5 |             0.151515  |
| Fine-tuned ViT | Industrial ↔ Residential             |        3 |             0.0909091 |
| Fine-tuned CNN | HerbaceousVegetation ↔ Pasture       |        8 |             0.166667  |
| Fine-tuned CNN | AnnualCrop ↔ PermanentCrop           |        7 |             0.145833  |
| Fine-tuned CNN | AnnualCrop ↔ Pasture                 |        5 |             0.104167  |
| Fine-tuned CNN | HerbaceousVegetation ↔ PermanentCrop |        5 |             0.104167  |
| Fine-tuned CNN | Industrial ↔ Residential             |        5 |             0.104167  |

## Corruption results

| pipeline       | condition       |   clean accuracy |   corrupted accuracy |   drop (percentage points) |
|:---------------|:----------------|-----------------:|---------------------:|---------------------------:|
| Fine-tuned ViT | blur            |         0.991852 |             0.849877 |                  14.1975   |
| Fine-tuned ViT | brightness_x0.6 |         0.991852 |             0.975062 |                   1.67901  |
| Fine-tuned ViT | brightness_x1.4 |         0.991852 |             0.987654 |                   0.419753 |
| Fine-tuned ViT | haze            |         0.991852 |             0.974321 |                   1.75309  |
| Fine-tuned CNN | blur            |         0.988148 |             0.68321  |                  30.4938   |
| Fine-tuned CNN | brightness_x0.6 |         0.988148 |             0.974074 |                   1.40741  |
| Fine-tuned CNN | brightness_x1.4 |         0.988148 |             0.97284  |                   1.53086  |
| Fine-tuned CNN | haze            |         0.988148 |             0.984691 |                   0.345679 |

## Duplicate checks

{'train–validation': 0, 'train–test': 0, 'validation–test': 0}

## Selective prediction

| target coverage   |   threshold (validation) |   validation accepted |   validation coverage |   validation accepted accuracy |   test threshold |   test accepted |   test rejected |   test coverage |   test accepted accuracy |
|:------------------|-------------------------:|----------------------:|----------------------:|-------------------------------:|-----------------:|----------------:|----------------:|----------------:|-------------------------:|
| 1.0               |                 0.385397 |                  4050 |              1        |                       0.990123 |         0.385397 |            4050 |               0 |        1        |                 0.991852 |
| 0.9               |                 0.899978 |                  3646 |              0.900247 |                       0.99808  |         0.899978 |            3659 |             391 |        0.903457 |                 0.99918  |
| 0.8               |                 0.904851 |                  3241 |              0.800247 |                       0.998766 |         0.904851 |            3215 |             835 |        0.793827 |                 0.999689 |
| 0.7               |                 0.907253 |                  2835 |              0.7      |                       0.999295 |         0.907253 |            2821 |            1229 |        0.696543 |                 0.999646 |
| 0.5               |                 0.910273 |                  2025 |              0.5      |                       0.999012 |         0.910273 |            1987 |            2063 |        0.490617 |                 0.999497 |
| recommended       |                 0.831854 |                  3975 |              0.981481 |                       0.99522  |         0.831854 |            3982 |              68 |        0.98321  |                 0.997489 |

## Per-class corruption diagnostics

Positive values mean accuracy fell; negative values mean accuracy improved under that pipeline's worst corruption. This is a class-wise stress-test diagnostic, not a demographic or geographic fairness result.

| pipeline       | class                |   clean accuracy |   accuracy change under worst corruption (pp; negative = gain) |
|:---------------|:---------------------|-----------------:|---------------------------------------------------------------:|
| Fine-tuned ViT | AnnualCrop           |         0.986667 |                                                      -0.666667 |
| Fine-tuned ViT | Forest               |         0.995556 |                                                      50.8889   |
| Fine-tuned ViT | HerbaceousVegetation |         0.993333 |                                                       1.55556  |
| Fine-tuned ViT | Highway              |         0.994667 |                                                       1.6      |
| Fine-tuned ViT | Industrial           |         0.994667 |                                                       1.86667  |
| Fine-tuned ViT | Pasture              |         0.98     |                                                       3        |
| Fine-tuned ViT | PermanentCrop        |         0.978667 |                                                      30.6667   |
| Fine-tuned ViT | Residential          |         0.997778 |                                                      43.5556   |
| Fine-tuned ViT | River                |         0.997333 |                                                       2.93333  |
| Fine-tuned ViT | SeaLake              |         0.995556 |                                                      -0.444444 |
| Fine-tuned CNN | AnnualCrop           |         0.984444 |                                                      -0.888889 |
| Fine-tuned CNN | Forest               |         0.995556 |                                                      99.3333   |
| Fine-tuned CNN | HerbaceousVegetation |         0.975556 |                                                       9.77778  |
| Fine-tuned CNN | Highway              |         0.994667 |                                                       3.46667  |
| Fine-tuned CNN | Industrial           |         0.986667 |                                                       3.73333  |
| Fine-tuned CNN | Pasture              |         0.99     |                                                      15.3333   |
| Fine-tuned CNN | PermanentCrop        |         0.965333 |                                                      58.6667   |
| Fine-tuned CNN | Residential          |         0.993333 |                                                      93.1111   |
| Fine-tuned CNN | River                |         0.994667 |                                                       9.6      |
| Fine-tuned CNN | SeaLake              |         1        |                                                       0        |

## Limitations

Single seed; confounded pipelines; BiT default input 448 versus 224 used; spatial leakage may inflate random-split scores; Europe-only coverage; RGB-only inputs.